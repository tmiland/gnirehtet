@gnirehtet.exe run
@pause
